# Cour CSharp

## Ressource:
[Google Slide CSharp FRANCOIS Joan](https://docs.google.com/presentation/d/1wYfETWW2q9pm0r9OsHyRWxeOhX63QFOe0Xpy6O9i-fA/edit#slide=id.g372f9b7c23_0_91)
