package com.studiopixidream.appmusic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView listViewMusics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listViewMusics = findViewById(R.id.listViewMusic);
        MusicAdapter musicAdapter = new MusicAdapter(this, sampleMusics());
        listViewMusics.setAdapter(musicAdapter);
    }

    private ArrayList<Music> sampleMusics () {
        ArrayList<Music> musics = new ArrayList<Music>();
        musics.add(
                new Music(
                    1260681532,
                    "Amazonia",
                    "Gojira",
                    "Amazonia",
                    "https://cdns-images.dzcdn.net/images/cover/58c0fc2ba2dc8f529a9907be600c2944/1000x1000-000000-80-0-0.jpg",
                    "https://www.deezer.com/fr/track/1260681532",
                        "https://cdns-preview-e.dzcdn.net/stream/c-e9142bd9ce8058167abfafd50fb549df-3.mp3"
                )
        );
        musics.add(
                new Music(
                        1242654742,
                        "Born For One Thing",
                        "Gojira",
                        "Born For One Thing",
                        "https://cdns-images.dzcdn.net/images/cover/58c0fc2ba2dc8f529a9907be600c2944/1000x1000-000000-80-0-0.jpg",
                        "https://www.deezer.com/artist/2993",
                        "https://cdns-preview-1.dzcdn.net/stream/c-12389f9dbdcb5c565e1e46b1a9e8d48b-3.mp3"
                )
        );
        musics.add(
                new Music(
                        126338363,
                        "Silvera",
                        "Gojira",
                        "Magma",
                        "https://cdns-images.dzcdn.net/images/cover/cc9b867b6847741d0b64b79f85982f1d/1000x1000-000000-80-0-0.jpg",
                        "https://www.deezer.com/artist/2993",
                        "https://cdns-preview-a.dzcdn.net/stream/c-ababc03e073454584ddc9e45c3ec31b6-7.mp3"
                )
        );

        return musics;
    }
}